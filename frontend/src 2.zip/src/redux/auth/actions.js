import * as actionTypes from './types';

// ================= LOGIN =================
export const login =
  ({ loginData }) =>
  async (dispatch) => {
    dispatch({
      type: actionTypes.REQUEST_LOADING,
    });

    const savedAuth = JSON.parse(localStorage.getItem('auth'));

    // 🔴 First-time fallback (seed default user)
    if (!savedAuth) {
      const defaultUser = {
        name: 'Admin',
        surname: 'User',
        email: 'admin@admin.com',
        password: 'admin123',
        role: 'owner',
      };

      const auth_state = {
        current: defaultUser,
        token: 'local-token',
        isLoggedIn: true,
        isLoading: false,
        isSuccess: true,
      };

      localStorage.setItem('auth', JSON.stringify(auth_state));

      // allow login with default credentials
      if (
        loginData.email === defaultUser.email &&
        loginData.password === defaultUser.password
      ) {
        dispatch({
          type: actionTypes.REQUEST_SUCCESS,
          payload: defaultUser,
        });
      } else {
        alert('Use default credentials: admin@admin.com / admin123');
        dispatch({ type: actionTypes.REQUEST_FAILED });
      }

      return;
    }

    // 🔐 Validate credentials
    if (
      loginData.email === savedAuth.current.email &&
      loginData.password === savedAuth.current.password
    ) {
      dispatch({
        type: actionTypes.REQUEST_SUCCESS,
        payload: savedAuth.current,
      });
    } else {
      alert('Invalid credentials');
      dispatch({
        type: actionTypes.REQUEST_FAILED,
      });
    }
  };

// ================= REGISTER (DISABLED / OPTIONAL) =================
export const register =
  ({ registerData }) =>
  async (dispatch) => {
    dispatch({
      type: actionTypes.REQUEST_FAILED,
    });
  };

// ================= VERIFY (DISABLED) =================
export const verify =
  () =>
  async (dispatch) => {
    dispatch({
      type: actionTypes.REQUEST_FAILED,
    });
  };

// ================= RESET PASSWORD (DISABLED) =================
export const resetPassword =
  () =>
  async (dispatch) => {
    dispatch({
      type: actionTypes.REQUEST_FAILED,
    });
  };

// ================= LOGOUT =================
export const logout = () => async (dispatch) => {
  dispatch({
    type: actionTypes.LOGOUT_SUCCESS,
  });

  localStorage.removeItem('auth');
  localStorage.setItem('isLogout', JSON.stringify({ isLogout: true }));
};

// ================= UPDATE PROFILE =================
export const updateProfile =
  ({ jsonData }) =>
  async (dispatch) => {
    const auth = JSON.parse(localStorage.getItem('auth'));

    if (!auth) return;

    const updatedUser = {
      ...auth.current,
      name: jsonData.name,
      email: jsonData.email,
      password: jsonData.password || auth.current.password,
    };

    const auth_state = {
      current: updatedUser,
      token: 'local-token',
      isLoggedIn: true,
      isLoading: false,
      isSuccess: true,
    };

    localStorage.setItem('auth', JSON.stringify(auth_state));

    dispatch({
      type: actionTypes.REQUEST_SUCCESS,
      payload: updatedUser,
    });
  };