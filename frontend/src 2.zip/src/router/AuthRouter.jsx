import { BrowserRouter, Routes, Route } from 'react-router-dom';
import LoginPage from './pages/Login.jsx';
import AppRouter from './router/AppRouter.jsx';

const isAuthenticated = () => {
  return localStorage.getItem('isLoggedIn') === 'true';
};

export default function RootApp() {
  return (
    <BrowserRouter>
      <Routes>
        {!isAuthenticated() ? (
          <Route path="*" element={<LoginPage />} />
        ) : (
          <Route path="/*" element={<AppRouter />} />
        )}
      </Routes>
    </BrowserRouter>
  );
}