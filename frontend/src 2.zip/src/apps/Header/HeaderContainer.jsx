import { useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { Avatar, Dropdown, Layout } from 'antd';

import { LogoutOutlined, UserOutlined } from '@ant-design/icons';

import { selectCurrentAdmin } from '@/redux/auth/selectors';
import { FILE_BASE_URL } from '@/config/serverApiConfig';
import useLanguage from '@/locale/useLanguage';

export default function HeaderContent() {
  const currentAdmin = useSelector(selectCurrentAdmin);
  const { Header } = Layout;

  const translate = useLanguage();

  const ProfileDropdown = () => {
    const navigate = useNavigate();

    return (
      <div
        className="profileDropdown"
        onClick={() => navigate('/profile')}
        style={{
          cursor: 'pointer',
        }}
      >
        <Avatar
          size="large"
          className="last"
          src={currentAdmin?.photo ? FILE_BASE_URL + currentAdmin?.photo : undefined}
          style={{
            color: '#fff',
            backgroundColor: '#1e293b',
            boxShadow: '0 0 10px rgba(56,189,248,0.3)',
          }}
        >
          {currentAdmin?.name?.charAt(0)?.toUpperCase() || 'A'}
        </Avatar>

        <div className="profileDropdownInfo">
          <p style={{ color: '#e2e8f0' }}>
            {currentAdmin?.name || 'ThreatLens'} {currentAdmin?.surname || 'Admin'}
          </p>
          <p style={{ color: '#94a3b8' }}>
            {currentAdmin?.email || 'admin@threatlens.com'}
          </p>
        </div>
      </div>
    );
  };

  const items = [
    {
      label: <ProfileDropdown />,
      key: 'ProfileDropdown',
    },
    {
      type: 'divider',
    },
    {
      icon: <UserOutlined />,
      key: 'settingProfile',
      label: <Link to="/profile">{translate('profile_settings')}</Link>,
    },
    {
      type: 'divider',
    },
    {
      icon: <LogoutOutlined />,
      key: 'logout',
      label: <Link to="/logout">{translate('logout')}</Link>,
    },
  ];

  return (
    <Header
      style={{
        padding: '15px 20px',
        background: '#020617',
        borderBottom: '1px solid #1e293b',
        display: 'flex',
        flexDirection: 'row-reverse',
        alignItems: 'center',
        gap: '15px',
      }}
    >
      <Dropdown
        menu={{ items }}
        trigger={['click']}
        placement="bottomRight"
      >
        <Avatar
          className="last"
          src={currentAdmin?.photo ? FILE_BASE_URL + currentAdmin?.photo : undefined}
          style={{
            color: '#fff',
            backgroundColor: '#1e293b',
            boxShadow: '0 0 12px rgba(56,189,248,0.4)',
            cursor: 'pointer',
          }}
          size="large"
        >
          {currentAdmin?.name?.charAt(0)?.toUpperCase() || 'A'}
        </Avatar>
      </Dropdown>
    </Header>
  );
}