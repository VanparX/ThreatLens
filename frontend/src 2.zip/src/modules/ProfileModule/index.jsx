import Profile from './components/Profile';
import ProfileLayout from '@/layout/ProfileLayout';
import { Layout } from 'antd';
import { Content } from 'antd/lib/layout/layout';

export default function ProfileModule({ config }) {
  return (
    <ProfileLayout>
      <Layout className="site-layout" style={{ background: '#020617' }}>
        <Content
          style={{
            padding: '40px',
            margin: '60px auto',
            width: '100%',
            maxWidth: '900px',
            background: '#1e293b',
            borderRadius: '12px',
            border: '1px solid #1e293b',
            boxShadow: '0 0 20px rgba(0,0,0,0.6)',
          }}
        >
          <Profile config={config} />
        </Content>
      </Layout>
    </ProfileLayout>
  );
}