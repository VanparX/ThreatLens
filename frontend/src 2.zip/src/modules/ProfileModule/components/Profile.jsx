import { useProfileContext } from '@/context/profileContext';
import AdminInfo from './AdminInfo';
import UpdateAdmin from './UpdateAdmin';
import PasswordModal from './PasswordModal';

export default function Profile({ config }) {
  const { state } = useProfileContext();
  const { update, read } = state;

  return (
    <div
      style={{
        position: 'relative',
        minHeight: '300px',
      }}
    >
      {/* 🔥 VIEW MODE */}
      <div
        style={{
          opacity: read.isOpen ? 1 : 0,
          transform: read.isOpen ? 'translateY(0px)' : 'translateY(20px)',
          transition: 'all 0.3s ease',
          position: read.isOpen ? 'relative' : 'absolute',
          width: '100%',
        }}
      >
        <AdminInfo config={config} />
      </div>

      {/* 🔥 EDIT MODE */}
      <div
        style={{
          opacity: update.isOpen ? 1 : 0,
          transform: update.isOpen ? 'translateY(0px)' : 'translateY(20px)',
          transition: 'all 0.3s ease',
          position: update.isOpen ? 'relative' : 'absolute',
          width: '100%',
        }}
      >
        <UpdateAdmin config={config} />
      </div>

      {/* 🔐 PASSWORD MODAL */}
      <PasswordModal />
    </div>
  );
}