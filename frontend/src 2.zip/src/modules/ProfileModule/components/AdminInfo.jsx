import { useProfileContext } from '@/context/profileContext';
import { generate as uniqueId } from 'shortid';
import { EditOutlined, LockOutlined, LogoutOutlined } from '@ant-design/icons';
import { Avatar, Button, Col, Row } from 'antd';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';

import { selectCurrentAdmin } from '@/redux/auth/selectors';
import useLanguage from '@/locale/useLanguage';
import { FILE_BASE_URL } from '@/config/serverApiConfig';

const AdminInfo = ({ config }) => {
  const translate = useLanguage();
  const navigate = useNavigate();
  const { profileContextAction } = useProfileContext();
  const { modal, updatePanel } = profileContextAction;
  const { ENTITY_NAME } = config;
  const currentAdmin = useSelector(selectCurrentAdmin);

  return (
    <div style={{ color: '#e2e8f0' }}>
      {/* 🔥 HEADER */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '30px',
        }}
      >
        <h2 style={{ margin: 0 }}>{ENTITY_NAME}</h2>

        <div style={{ display: 'flex', gap: '10px' }}>
          <Button
            key={uniqueId()}
            onClick={() => updatePanel.open()}
            type="primary"
            icon={<EditOutlined />}
            style={{ background: '#14b8a6', border: 'none' }}
          >
            {translate('Edit')}
          </Button>

          <Button
            key={uniqueId()}
            icon={<LockOutlined />}
            onClick={() => modal.open()}
            style={{
              background: '#1e293b',
              color: '#e2e8f0',
              border: '1px solid #334155',
            }}
          >
            {translate('Update Password')}
          </Button>
        </div>
      </div>

      {/* 🔥 PROFILE SECTION */}
      <Row align="middle" gutter={20}>
        <Col xs={24} sm={6}>
          <Avatar
            src={currentAdmin?.photo ? FILE_BASE_URL + currentAdmin?.photo : undefined}
            size={100}
            style={{
              backgroundColor: currentAdmin?.photo ? 'none' : '#0ea5e9',
              fontSize: '40px',
              boxShadow: '0 0 20px rgba(14,165,233,0.6)',
            }}
          >
            {currentAdmin?.name?.charAt(0)?.toUpperCase()}
          </Avatar>
        </Col>

        <Col xs={24} sm={18}>
          <div style={{ lineHeight: '2' }}>
            <p>
              <strong style={{ color: '#94a3b8' }}>First Name:</strong>{' '}
              {currentAdmin?.name}
            </p>

            <p>
              <strong style={{ color: '#94a3b8' }}>Last Name:</strong>{' '}
              {currentAdmin?.surname}
            </p>

            <p>
              <strong style={{ color: '#94a3b8' }}>Email:</strong>{' '}
              {currentAdmin?.email}
            </p>

            <p>
              <strong style={{ color: '#94a3b8' }}>Role:</strong>{' '}
              {currentAdmin?.role}
            </p>
          </div>
        </Col>
      </Row>

      {/* 🔥 DIVIDER */}
      <div
        style={{
          margin: '30px 0',
          height: '1px',
          background: '#1e293b',
        }}
      />

      {/* 🔥 LOGOUT */}
      <div style={{ textAlign: 'right' }}>
        <Button
          key={uniqueId()}
          icon={<LogoutOutlined />}
          onClick={() => navigate('/logout')}
          style={{
            background: '#020617',
            color: '#e2e8f0',
            border: '1px solid #334155',
          }}
        >
          {translate('Logout')}
        </Button>
      </div>
    </div>
  );
};

export default AdminInfo;