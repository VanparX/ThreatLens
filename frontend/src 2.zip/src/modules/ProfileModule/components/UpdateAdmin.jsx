import { useState } from 'react';
import { useSelector } from 'react-redux';
import { Button, Input } from 'antd';
import { useProfileContext } from '@/context/profileContext';
import { selectCurrentAdmin } from '@/redux/auth/selectors';
import axios from 'axios';

export default function UpdateAdmin() {
  const { profileContextAction } = useProfileContext();
  const { updatePanel } = profileContextAction;

  const currentAdmin = useSelector(selectCurrentAdmin);

  const [name, setName] = useState(currentAdmin?.name || '');
  const [email, setEmail] = useState(currentAdmin?.email || '');
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleUpdate = async () => {
    // 🔒 BASIC VALIDATION
    if (!name || !email) {
      alert('Name and Email are required');
      return;
    }

    try {
      setLoading(true);

      // 🔑 TOKEN (IMPORTANT)
      const token = localStorage.getItem('authToken');

      // 🧠 BUILD PAYLOAD SMARTLY
      const payload = {
        name,
        email,
      };

      // Only send password if user entered it
      if (oldPassword && newPassword) {
        payload.oldPassword = oldPassword;
        payload.newPassword = newPassword;
      }

      // 🚀 API CALL (MATCH YOUR BACKEND)
      await axios.patch(
        'http://localhost:8888/api/admin/updateProfile',
        payload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      alert('Profile updated successfully');

      updatePanel.close();

      // ⚡ Soft refresh instead of reload (better UX)
      window.location.reload();

    } catch (err) {
      console.error(err);
      alert(err.response?.data?.message || 'Update failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ color: '#e2e8f0' }}>
      {/* 🔥 HEADER */}
      <h2 style={{ marginBottom: '20px' }}>Edit Profile</h2>

      {/* 🔥 FORM */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
        <Input
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          style={{ background: '#020617', color: '#fff', border: '1px solid #334155' }}
        />

        <Input
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          style={{ background: '#020617', color: '#fff', border: '1px solid #334155' }}
        />

        <Input.Password
          placeholder="Old Password (optional)"
          value={oldPassword}
          onChange={(e) => setOldPassword(e.target.value)}
          style={{ background: '#020617', color: '#fff', border: '1px solid #334155' }}
        />

        <Input.Password
          placeholder="New Password (optional)"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          style={{ background: '#020617', color: '#fff', border: '1px solid #334155' }}
        />

        {/* 🔥 ACTIONS */}
        <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
          <Button
            type="primary"
            loading={loading}
            onClick={handleUpdate}
            style={{
              background: '#14b8a6',
              border: 'none',
              fontWeight: '500',
            }}
          >
            Save Changes
          </Button>

          <Button
            onClick={() => updatePanel.close()}
            style={{
              background: '#1e293b',
              color: '#e2e8f0',
              border: '1px solid #334155',
            }}
          >
            Cancel
          </Button>
        </div>
      </div>
    </div>
  );
}