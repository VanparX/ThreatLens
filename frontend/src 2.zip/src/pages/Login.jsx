import { useState } from 'react';
import { Form, Input, Button, Card } from 'antd';

export default function LoginPage() {
  const [loading, setLoading] = useState(false);

  const onFinish = (values) => {
    setLoading(true);

    const { username, password } = values;

    if (
      username === 'Pardhu@threatlens' &&
      password === 'threatlens123'
    ) {
      localStorage.setItem('isLoggedIn', 'true');

      // 🔥 full reload → router + layout load properly
      window.location.href = '/';
    } else {
      alert('Invalid credentials');
    }

    setLoading(false);
  };

  return (
    <div
      style={{
        height: '100vh',
        background: '#020617',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      <Card
        style={{
          width: 360,
          background: '#0f172a',
          border: '1px solid #1e293b',
          borderRadius: '12px',
          boxShadow: '0 0 40px rgba(0,0,0,0.6)',
        }}
      >
        <h2 style={{ color: '#e2e8f0', textAlign: 'center' }}>
          ThreatLens Login
        </h2>

        <Form layout="vertical" onFinish={onFinish}>
          <Form.Item
            label={<span style={{ color: '#94a3b8' }}>Username</span>}
            name="username"
            rules={[{ required: true }]}
          >
            <Input
              placeholder="Pardhu@threatlens"
              style={{
                background: '#020617',
                color: '#e2e8f0',
                border: '1px solid #334155',
              }}
            />
          </Form.Item>

          <Form.Item
            label={<span style={{ color: '#94a3b8' }}>Password</span>}
            name="password"
            rules={[{ required: true }]}
          >
            <Input.Password
              placeholder="••••••••"
              style={{
                background: '#020617',
                color: '#e2e8f0',
                border: '1px solid #334155',
              }}
            />
          </Form.Item>

          <Button
            type="primary"
            htmlType="submit"
            loading={loading}
            block
            style={{
              background: '#14b8a6',
              border: 'none',
              height: '40px',
            }}
          >
            Login
          </Button>
        </Form>
      </Card>
    </div>
  );
}