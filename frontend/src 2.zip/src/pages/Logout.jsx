import { useEffect } from 'react';

export default function Logout() {
  useEffect(() => {
    // ✅ Clear login flag
    localStorage.removeItem('isLoggedIn');

    // 🔥 Force redirect to login
    window.location.href = '/login';
  }, []);

  return null;
}