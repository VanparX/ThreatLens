import { BrowserRouter } from 'react-router-dom';
import AppRouter from './router/AppRouter.jsx';
import AuthRouter from './router/AuthRouter.jsx';

const isAuthenticated = () => {
  return localStorage.getItem('isLoggedIn') === 'true';
};

export default function RootApp() {
  return (
    <BrowserRouter>
      {isAuthenticated() ? <AppRouter /> : <AuthRouter />}
    </BrowserRouter>
  );
}