import { useState, useEffect } from 'react';
import { useCrudContext } from '@/context/crud';
import { Grid, Layout, Drawer } from 'antd';
import CollapseBox from '../CollapseBox';

const { useBreakpoint } = Grid;

export default function SidePanel({ config, topContent, bottomContent, fixHeaderPanel }) {
  const screens = useBreakpoint();

  const { ADD_NEW_ENTITY } = config;
  const { state, crudContextAction } = useCrudContext();
  const { isPanelClose, isBoxCollapsed } = state;
  const { panel, collapsedBox } = crudContextAction;

  const [isSidePanelClose, setSidePanel] = useState(isPanelClose);
  const [opacitySider, setOpacitySider] = useState(0);
  const [paddingTopSider, setPaddingTopSider] = useState('20px');

  useEffect(() => {
    let timer = [];

    if (isPanelClose) {
      setOpacitySider(0);
      setPaddingTopSider('20px');

      timer = setTimeout(() => {
        setSidePanel(isPanelClose);
      }, 200);
    } else {
      setSidePanel(isPanelClose);

      timer = setTimeout(() => {
        setOpacitySider(1);
        setPaddingTopSider(0);
      }, 200);
    }

    return () => clearTimeout(timer);
  }, [isPanelClose]);

  const collapsePanel = () => {
    panel.collapse();
  };

  const collapsePanelBox = () => {
    collapsedBox.collapse();
  };

  return (
    <Drawer
      title={<span style={{ color: '#e2e8f0' }}>{config.PANEL_TITLE}</span>}
      placement="right"
      onClose={collapsePanel}
      open={!isPanelClose}
      width={450}
      bodyStyle={{
        background: '#020617',
        color: '#e2e8f0',
      }}
      headerStyle={{
        background: '#020617',
        borderBottom: '1px solid #1e293b',
      }}
    >
      <div
        className="sidePanelContent"
        style={{
          opacity: opacitySider,
          paddingTop: paddingTopSider,
        }}
      >
        {fixHeaderPanel}

        <CollapseBox
          buttonTitle={ADD_NEW_ENTITY}
          isCollapsed={isBoxCollapsed}
          onCollapse={collapsePanelBox}
          topContent={topContent}
          bottomContent={bottomContent}
        />
      </div>
    </Drawer>
  );
}